<?php
include 'config.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
  case 'GET':
    $result = $conn->query("SELECT * FROM matches ORDER BY timestamp DESC");
    $matches = [];
    while ($row = $result->fetch_assoc()) {
      $match_id = $row['id'];
      $players_result = $conn->query("SELECT name, score FROM match_players WHERE match_id = $match_id");
      $players = [];
      while ($player_row = $players_result->fetch_assoc()) {
        $players[] = [
          'name' => $player_row['name'],
          'score' => (int)$player_row['score']
        ];
      }
      $matches[] = [
        'timestamp' => (int)$row['timestamp'],
        'players' => $players,
        'duration' => (int)$row['duration']
      ];
    }
    echo json_encode($matches);
    break;

  case 'POST':
    $data = json_decode(file_get_contents('php://input'), true);
    $timestamp = $data['timestamp'];
    $duration = $data['duration'];
    $players = $data['players'];

    $conn->begin_transaction();
    try {
      $stmt = $conn->prepare("INSERT INTO matches (timestamp, duration) VALUES (?, ?)");
      $stmt->bind_param('ii', $timestamp, $duration);
      $stmt->execute();
      $match_id = $stmt->insert_id;

      foreach ($players as $player) {
        $name = $player['name'];
        $score = $player['score'];
        $stmt = $conn->prepare("INSERT INTO match_players (match_id, name, score) VALUES (?, ?, ?)");
        $stmt->bind_param('isi', $match_id, $name, $score);
        $stmt->execute();
      }

      $conn->commit();
      echo json_encode(['success' => true]);
    } catch (Exception $e) {
      $conn->rollback();
      echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    break;

  case 'DELETE':
    $timestamp = $_GET['timestamp'];
    $conn->begin_transaction();
    try {
      // 使用预处理语句避免SQL注入
      $stmt = $conn->prepare("SELECT id FROM matches WHERE timestamp = ?");
      $stmt->bind_param('i', $timestamp);
      $stmt->execute();
      $result = $stmt->get_result();
      
      if ($row = $result->fetch_assoc()) {
        $match_id = $row['id'];
        
        // 删除比赛选手记录
        $stmt = $conn->prepare("DELETE FROM match_players WHERE match_id = ?");
        $stmt->bind_param('i', $match_id);
        $stmt->execute();
        
        // 删除比赛记录
        $stmt = $conn->prepare("DELETE FROM matches WHERE id = ?");
        $stmt->bind_param('i', $match_id);
        $stmt->execute();
        
        $conn->commit();
        echo json_encode(['success' => true]);
      } else {
        $conn->commit();
        echo json_encode(['success' => false, 'error' => '比赛记录不存在']);
      }
    } catch (Exception $e) {
      $conn->rollback();
      echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    break;
}
?>
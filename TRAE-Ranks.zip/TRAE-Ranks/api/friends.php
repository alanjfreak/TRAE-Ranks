<?php
include 'config.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
  case 'GET':
    $result = $conn->query("SELECT * FROM friends");
    $friends = [];
    while ($row = $result->fetch_assoc()) {
      $friends[] = [
        'name' => $row['name'],
        'total' => [
          'win' => (int)$row['total_win'],
          'lose' => (int)$row['total_lose'],
          'winRate' => calculateWinRate($row['total_win'], $row['total_lose'])
        ],
        'week' => [
          'win' => (int)$row['week_win'],
          'lose' => (int)$row['week_lose'],
          'winRate' => calculateWinRate($row['week_win'], $row['week_lose'])
        ],
        'month' => [
          'win' => (int)$row['month_win'],
          'lose' => (int)$row['month_lose'],
          'winRate' => calculateWinRate($row['month_win'], $row['month_lose'])
        ],
        'season' => [
          'win' => (int)$row['season_win'],
          'lose' => (int)$row['season_lose'],
          'winRate' => calculateWinRate($row['season_win'], $row['season_lose'])
        ],
        'year' => [
          'win' => (int)$row['year_win'],
          'lose' => (int)$row['year_lose'],
          'winRate' => calculateWinRate($row['year_win'], $row['year_lose'])
        ]
      ];
    }
    echo json_encode($friends);
    break;

  case 'POST':
    $data = json_decode(file_get_contents('php://input'), true);
    $name = $data['name'];
    $stmt = $conn->prepare("INSERT INTO friends (name) VALUES (?)");
    $stmt->bind_param('s', $name);
    if ($stmt->execute()) {
      echo json_encode(['success' => true]);
    } else {
      echo json_encode(['success' => false, 'error' => $stmt->error]);
    }
    break;

  case 'DELETE':
    $name = $_GET['name'];
    $stmt = $conn->prepare("DELETE FROM friends WHERE name = ?");
    $stmt->bind_param('s', $name);
    if ($stmt->execute()) {
      echo json_encode(['success' => true]);
    } else {
      echo json_encode(['success' => false, 'error' => $stmt->error]);
    }
    break;
}

function calculateWinRate($win, $lose) {
  $total = $win + $lose;
  return $total > 0 ? number_format($win / $total * 100, 1) . '%' : '0.0%';
}
?>
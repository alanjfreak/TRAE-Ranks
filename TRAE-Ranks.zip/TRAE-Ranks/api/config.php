<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'svh_j8eagwo');  // 数据库名称
define('DB_USER', 'svh_j8eagwo');  // 数据库用户名
define('DB_PASS', '122333');  // 数据库密码

// 连接数据库
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
  die("连接失败: " . $conn->connect_error);
}
?>